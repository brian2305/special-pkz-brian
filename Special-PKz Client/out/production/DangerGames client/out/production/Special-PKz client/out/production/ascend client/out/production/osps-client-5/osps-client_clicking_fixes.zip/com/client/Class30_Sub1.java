package com.client;
// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

final class Class30_Sub1 extends Node {

	Class30_Sub1() {
		anInt1294 = -1;
	}

	public int anInt1291;
	public int anInt1292;
	public int anInt1293;
	public int anInt1294;
	public int anInt1295;
	public int anInt1296;
	public int anInt1297;
	public int anInt1298;
	public int anInt1299;
	public int anInt1300;
	public int anInt1301;
	public int anInt1302;
}
