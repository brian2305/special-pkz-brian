package com.client;
// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

final class Object4 {

	Object4() {
	}

	int anInt45;
	int anInt46;
	int anInt47;
	Renderable aClass30_Sub2_Sub4_48;
	Renderable aClass30_Sub2_Sub4_49;
	Renderable aClass30_Sub2_Sub4_50;
	int uid;
	int newuid;
	int anInt52;
}
