package com.client;

final class VertexNormal {

    public VertexNormal() {
    }

    int anInt602;
    int anInt603;
    int anInt604;
    int anInt605;
}
