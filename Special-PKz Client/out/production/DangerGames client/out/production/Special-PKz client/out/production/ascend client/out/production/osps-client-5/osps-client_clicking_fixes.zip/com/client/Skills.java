package com.client;
// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

final class Skills {

	public static final int SKILLS_COUNT = 25;
	public static String[] SKILL_NAMES = {
	        "-1", "Attack", "Strength", "Defence", "Ranged",
	        "Prayer", "Magic", "Runecrafting", "Construction", "Hitpoints", "Agility",
	        "Herblore", "Thieving", "Crafting", "Fletching", "Slayer", "Hunter", "-1",
	        "Mining", "Smithing", "Fishing", "Cooking", "Firemaking", "Woodcutting",
	        "Farming"
	    };
	public static final boolean[] SKILLS_ENABLED = { 
			true, true, true, true, true, true, true, true, true, true, 
			true, true, true, true, true, true, true, true, true, true, 
			true, true, false, false, false };

}
