package com.client.graphics.interfaces.impl;

import com.client.Configuration;
import com.client.graphics.interfaces.RSInterface;

public enum Dropdown {

	XP_POSITION() {
		@Override
		public void selectOption(int selected, RSInterface r) {
			Configuration.xpPosition = selected;
		}
	},
	
	XP_SIZE() {
		@Override
		public void selectOption(int selected, RSInterface r) {
			Configuration.xpSize = selected;
		}
	},
	
	XP_SPEED() {
		@Override
		public void selectOption(int selected, RSInterface r) {
			Configuration.xpSpeed = selected;
		}
	},
	
	XP_DURATION() {
		@Override
		public void selectOption(int selected, RSInterface r) {
			Configuration.xpDuration = selected;
		}
	},
	
	XP_COLOUR() {
		@Override
		public void selectOption(int selected, RSInterface r) {
			Configuration.xpColour = selected;
		}
	},
	
	XP_GROUP() {
		@Override
		public void selectOption(int selected, RSInterface r) {
			Configuration.xpGroup = selected;
		}
	},

	KEYBIND_SELECTION() {
		@Override
		public void selectOption(int selected, RSInterface dropdown) {
			Keybinding.bind((dropdown.id - Keybinding.MIN_FRAME) / 3, selected);
		}
	},

	PLAYER_ATTACK_OPTION_PRIORITY() {
		@Override
		public void selectOption(int selected, RSInterface r) {
			Configuration.playerAttackOptionPriority = selected;
		}
	},

	NPC_ATTACK_OPTION_PRIORITY() {
		@Override
		public void selectOption(int selected, RSInterface r) {
			Configuration.npcAttackOptionPriority = selected;
		}
	}
	;

	private Dropdown() { }

	public abstract void selectOption(int selected, RSInterface r);
}

