package com.client.graphics.interfaces;

public abstract class InterfaceTextInput {
	
	public abstract void handleInput();

}
