package com.client;
// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

final class Class32 {

	Class32() {
		anIntArray583 = new int[256];
		anIntArray585 = new int[257];
		aBooleanArray589 = new boolean[256];
		aBooleanArray590 = new boolean[16];
		aByteArray591 = new byte[256];
		aByteArray592 = new byte[4096];
		anIntArray593 = new int[16];
		aByteArray594 = new byte[18002];
		aByteArray595 = new byte[18002];
		aByteArrayArray596 = new byte[6][258];
		anIntArrayArray597 = new int[6][258];
		anIntArrayArray598 = new int[6][258];
		anIntArrayArray599 = new int[6][258];
		anIntArray600 = new int[6];
	}

	byte aByteArray563[];
	int anInt564;
	int anInt565;
	int anInt566;
	int anInt567;
	byte aByteArray568[];
	int anInt569;
	int anInt570;
	int anInt571;
	int anInt572;
	byte aByte573;
	int anInt574;
	boolean aBoolean575;
	int anInt576;
	int anInt577;
	int anInt578;
	int anInt579;
	int anInt580;
	int anInt581;
	int anInt582;
	final int[] anIntArray583;
	int anInt584;
	final int[] anIntArray585;
	public static int anIntArray587[];
	int anInt588;
	final boolean[] aBooleanArray589;
	final boolean[] aBooleanArray590;
	final byte[] aByteArray591;
	final byte[] aByteArray592;
	final int[] anIntArray593;
	final byte[] aByteArray594;
	final byte[] aByteArray595;
	final byte[][] aByteArrayArray596;
	final int[][] anIntArrayArray597;
	final int[][] anIntArrayArray598;
	final int[][] anIntArrayArray599;
	final int[] anIntArray600;
	int anInt601;
}
